using InteractionFlow.Core.Builders;
using System;

namespace InteractionFlow.Standard.Old.Builders
{
    /// <summary>
    /// 登録済みサービスから <see cref="ScopeHandler"/> を生成する標準ビルダーです。
    /// </summary>
    /// <remarks>
    /// <see cref="BuildScope(ScopeHandler[])"/> を一度試みるとサービス登録は消費され、
    /// Build の成否にかかわらず、このインスタンスを再利用できません。
    /// </remarks>
    public class ScopeBuilder : ScopeServices, IScopeBuilder
    {
        /// <summary>
        /// 現在のサービス登録からスコープを生成し、親スコープを関連付けます。
        /// </summary>
        /// <param name="parents">このスコープで解決できないサービスを探索する親スコープ。</param>
        /// <returns>生成されたスコープを管理するハンドラ。</returns>
        /// <exception cref="InvalidOperationException">このビルダーが Build によって消費済みの場合。</exception>
        public ScopeHandler BuildScope(params ScopeHandler[] parents)
        {
            var services = Services ?? throw new InvalidOperationException();
            try
            {
                return ScopeHandlerFactory.Create(services, parents);
            }
            finally
            {
                Services = null;
            }
        }
    }
}

using InteractionFlow.Core.Entities.Architectures;
using InteractionFlow.Core.Entities.Contexts;
using InteractionFlow.Core.Externals;
using InteractionFlow.Standard.Old.Console.Entities;
using InteractionFlow.Standard.Old.Console.ExternalPorts.ReactionPorts;
using System;
using System.Threading.Tasks;

namespace InteractionFlow.Standard.Old.Console.Externals.Reactions
{
    /// <summary>
    /// コンソールへ文字列を出力する標準 Reaction 実装です。
    /// </summary>
    public class ConsoleWriter : Reaction, IConsoleWriter
    {
        /// <summary>
        /// 既定のコンソール出力状態でインスタンスを作成します。
        /// </summary>
        /// <param name="dependency">この Reaction が依存するフローノード。</param>
        public ConsoleWriter(params IDependencyNode[] dependency) : base(dependency)
        {
            ResetFields();

            if (State == null)
                throw new ArgumentNullException("state");
        }

        /// <summary>
        /// コンソール出力に使用する状態を取得または設定します。
        /// </summary>
        public ConsoleState State { get; set; }

        /// <summary>
        /// コンソール出力状態を既定値へ戻します。
        /// </summary>
        public override void ForceResetMemoryState()
        {
            ResetFields();
        }

        private void ResetFields()
        {
            State = ConsoleState.Default;
        }

        /// <summary>
        /// 現在の状態に従ってコンソールへ文字列を書き込みます。
        /// </summary>
        /// <param name="context">出力時点のフローコンテキスト。</param>
        /// <param name="consoleOutput">出力する文字列。</param>
        /// <returns>出力後のフロー終了結果。</returns>
        public ValueTask<ReactionEnd> Write(IFlowContext context, ConsoleOutput consoleOutput)
        {
            using var cc = new ConsoleColorScope();
            cc.State = State.ColorSet;

            if (State.WriteLine)
            {
                global::System.Console.WriteLine(consoleOutput.text);
            }
            else
            {
                global::System.Console.Write(consoleOutput.text);
            }

            return new(GetEnd());
        }
    }
}
